var main_8cc =
[
    [ "analogies", "main_8cc.html#a7ffcd938d3c75d2f9249d6c122b780a4", null ],
    [ "main", "main_8cc.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "nn", "main_8cc.html#a821b5934bab6d9d7daf366e92a4621e4", null ],
    [ "predict", "main_8cc.html#a4479606e315746032f4ecde4b62ebc26", null ],
    [ "printAnalogiesUsage", "main_8cc.html#a2f26c98424ff31f8d5d4604f5bc91b15", null ],
    [ "printNgrams", "main_8cc.html#af2bf6913aa4d5fa8fa15100be6cbe705", null ],
    [ "printNNUsage", "main_8cc.html#a8126ecd2d93d3b73b1c516e323575052", null ],
    [ "printPredictUsage", "main_8cc.html#aa858ef5149aa995107818c079d930037", null ],
    [ "printPrintNgramsUsage", "main_8cc.html#a086a02edc37d73f760db2882df2ea57d", null ],
    [ "printPrintSentenceVectorsUsage", "main_8cc.html#a4328b0d06690e73334e2e7e1135efc37", null ],
    [ "printPrintWordVectorsUsage", "main_8cc.html#ab9897a3337e4f0833d547e044fd033eb", null ],
    [ "printQuantizeUsage", "main_8cc.html#aa743c1f04268af8569712a85c561a67f", null ],
    [ "printSentenceVectors", "main_8cc.html#a4c172f0e6b3cdcfac214743a95254c7d", null ],
    [ "printTestUsage", "main_8cc.html#a2cbfad77fba337d7d8b35790de95f0b8", null ],
    [ "printUsage", "main_8cc.html#aead97c99e70c0da7036fbbe230ef68b6", null ],
    [ "printWordVectors", "main_8cc.html#a133e93a6033465d23657e023a022c16e", null ],
    [ "quantize", "main_8cc.html#a6e07bb2da057cf6a518eed616b490bdd", null ],
    [ "test", "main_8cc.html#a425a56e6d14ed741a6565821124c9413", null ],
    [ "train", "main_8cc.html#a7137053a88d8b242fcac8625ce302b16", null ]
];