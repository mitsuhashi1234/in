var searchData=
[
  ['hs',['hs',['../namespacefasttext.html#a1ba04862fd670674501ccacc936e1952a789406d01073ca1782d86293dcfc0764',1,'fasttext']]]
];
