var searchData=
[
  ['sg',['sg',['../namespacefasttext.html#a349df214746a2ea0e5d7c26326b03d6fa5dae429688af1c521ad87ac394192c6d',1,'fasttext']]],
  ['softmax',['softmax',['../namespacefasttext.html#a1ba04862fd670674501ccacc936e1952ace2f1fbd249d24aabc07ac4488ab5b8c',1,'fasttext']]],
  ['sup',['sup',['../namespacefasttext.html#a349df214746a2ea0e5d7c26326b03d6fa2eeecd72c567401e6988624b179d0b14',1,'fasttext']]]
];
