var searchData=
[
  ['get_5fcentroids',['get_centroids',['../classfasttext_1_1ProductQuantizer.html#adb6a2ade7e4a77d7b59f03c081d11d91',1,'fasttext::ProductQuantizer::get_centroids(int32_t, uint8_t)'],['../classfasttext_1_1ProductQuantizer.html#a4f7b2b81820abc0c577a89a768ef3347',1,'fasttext::ProductQuantizer::get_centroids(int32_t, uint8_t) const']]],
  ['getcounts',['getCounts',['../classfasttext_1_1Dictionary.html#a8ebab8c3b38586edb9db35f9220ad72f',1,'fasttext::Dictionary']]],
  ['getdimension',['getDimension',['../classfasttext_1_1FastText.html#a32a93e0bc4389be11aa4be0990a9e010',1,'fasttext::FastText']]],
  ['getid',['getId',['../classfasttext_1_1Dictionary.html#a3d94bd710f83b125a68129e8a1638d1d',1,'fasttext::Dictionary']]],
  ['getlabel',['getLabel',['../classfasttext_1_1Dictionary.html#ac8860d22b56331b8d5c8eb9e31873864',1,'fasttext::Dictionary']]],
  ['getline',['getLine',['../classfasttext_1_1Dictionary.html#a7f851dbfcd6b9bd032e6dc3e387fd543',1,'fasttext::Dictionary::getLine(std::istream &amp;, std::vector&lt; int32_t &gt; &amp;, std::vector&lt; int32_t &gt; &amp;, std::vector&lt; int32_t &gt; &amp;, std::minstd_rand &amp;) const'],['../classfasttext_1_1Dictionary.html#a38a657e0e9143e1d22a7e24eaeb5a659',1,'fasttext::Dictionary::getLine(std::istream &amp;, std::vector&lt; int32_t &gt; &amp;, std::vector&lt; int32_t &gt; &amp;, std::minstd_rand &amp;) const']]],
  ['getloss',['getLoss',['../classfasttext_1_1Model.html#adab141691a82b572ab80f6bbb5ded6d1',1,'fasttext::Model']]],
  ['getm',['getM',['../classfasttext_1_1QMatrix.html#a16350455c02cf5f00175b1b0c6a310cd',1,'fasttext::QMatrix']]],
  ['getn',['getN',['../classfasttext_1_1QMatrix.html#ad969042dfc46a64e386f12616a4d6bcb',1,'fasttext::QMatrix']]],
  ['getnegative',['getNegative',['../classfasttext_1_1Model.html#a572a3c164d6e88120a8384330e2834dc',1,'fasttext::Model']]],
  ['getsubwords',['getSubwords',['../classfasttext_1_1Dictionary.html#a0ed089d9e5cbce60a647f912d6f8bd24',1,'fasttext::Dictionary::getSubwords(int32_t) const'],['../classfasttext_1_1Dictionary.html#ace021fb98186f100dd8cfba63c7302af',1,'fasttext::Dictionary::getSubwords(const std::string &amp;) const'],['../classfasttext_1_1Dictionary.html#a2f947d8754a28b9da9c5b5499164c130',1,'fasttext::Dictionary::getSubwords(const std::string &amp;, std::vector&lt; int32_t &gt; &amp;, std::vector&lt; std::string &gt; &amp;) const']]],
  ['gettype',['getType',['../classfasttext_1_1Dictionary.html#a80921e470e51d8adc3430fc96c97678f',1,'fasttext::Dictionary::getType(int32_t) const'],['../classfasttext_1_1Dictionary.html#a74a982138d4e4e703aee4c7e187b3448',1,'fasttext::Dictionary::getType(const std::string &amp;) const']]],
  ['getvector',['getVector',['../classfasttext_1_1FastText.html#ace850e40405e56ab488d32f25e5d3533',1,'fasttext::FastText']]],
  ['getword',['getWord',['../classfasttext_1_1Dictionary.html#aa6496f6eaa28851eb526f16792ffc9e8',1,'fasttext::Dictionary']]],
  ['grad_5f',['grad_',['../classfasttext_1_1Model.html#a79bd4bcbd2e6f10c5483249dfea74e97',1,'fasttext::Model']]]
];
