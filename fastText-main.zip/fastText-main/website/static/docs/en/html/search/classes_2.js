var searchData=
[
  ['entry',['entry',['../structfasttext_1_1entry.html',1,'fasttext']]]
];
