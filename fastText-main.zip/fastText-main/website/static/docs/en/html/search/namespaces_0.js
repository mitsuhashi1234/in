var searchData=
[
  ['fasttext',['fasttext',['../namespacefasttext.html',1,'']]],
  ['utils',['utils',['../namespacefasttext_1_1utils.html',1,'fasttext']]]
];
