document.addEventListener("DOMContentLoaded", function() {
    var favoriteLinks = document.querySelectorAll(".add-fav");
    favoriteLinks.forEach(function(link) {
        var imgElement = link.querySelector('img');
        var searchWord = link.getAttribute('data-search-word');
        var resultWord = link.getAttribute('data-result-word');
        var key = 'favorite-' + searchWord + '-' + resultWord;
        if (localStorage.getItem(key) === 'true') {
            imgElement.src = "/static/img/お気に入り追加済み.png";
        } else {
            imgElement.src = "/static/img/お気に入り.png";
        }

        // クリックイベントを設定
        link.onclick = function() {
            return changeFavoriteImage(link, searchWord, resultWord);
        };
    });
});

function changeFavoriteImage(linkElement, searchWord, resultWord) {
    var imgElement = linkElement.querySelector('img');
    var key = 'favorite-' + searchWord + '-' + resultWord;
    var isFavorite = localStorage.getItem(key) === 'true';

    if (!isFavorite) {
        imgElement.src = "/static/img/お気に入り追加済み.png";
        localStorage.setItem(key, 'true'); // 状態をローカルストレージに保存
    } else {
        imgElement.src = "/static/img/お気に入り.png";
        localStorage.removeItem(key); // ローカルストレージから削除
    }

    return false;
}