import fasttext
import faiss
import numpy as np
import ExtractVowels
from flask import Flask, render_template, request, session, redirect, url_for,flash, send_from_directory
from flask_session import Session
import mysql.connector

model = fasttext.load_model('cc.ja.300.bin')

def remove_duplicates(similarities):
    unique_words = set()
    unique_similarities = []
    for word, hurigana, similarity in similarities:
        if word not in unique_words:
            unique_words.add(word)
            unique_similarities.append((word, hurigana, similarity))
    return unique_similarities

def search_result(search_word, words,vowels,hurigana):
    result = []
    target_vowels = ExtractVowels.extract_vowels(search_word) #検索ワードの母音を抜き出し
    target_vowels= target_vowels

    for word, v, hurigana in zip(words, vowels, hurigana):
        v=v.replace("\r","")
        if v == target_vowels and word != search_word:
            hiragana = ExtractVowels.to_hiragana(hurigana)
            #print("word,v"+ word,v)
            result.append((word,hiragana))
#以下、CSS試すときに使いやつ
    # if len(result) == 0:
    #     return [('該当ワードなし',"なし",1)]
    
    # # 単語の類似度をすべて1に設定
    # result_with_similarity = [(word, hurigana, 1) for word , hurigana in result]

    # # 重複を削除
    # result_with_similarity = list(set(result_with_similarity))
    # result_with_similarity = sorted(result_with_similarity, key=lambda x: x[1], reverse=False)

    # return result_with_similarity
#以下、本使用
    #Faissを使用して類似性検索
    target_vec = model.get_word_vector(search_word).astype('float32')  # 入力ワードのベクトル化
    word_vecs = np.array([model.get_word_vector(word).astype('float32') for word, _ in result])  # 母音が一致しているワードのベクトル化
    if len(word_vecs) == 0:
        return [('該当ワードなし','なし',0)]
    

    # Faissインデックスの作成（コサイン類似度を使用するため、IndexFlatIPを使用）
    index = faiss.IndexFlatIP(target_vec.shape[0])
    index.add(word_vecs)

    # 類似度検索
    _, indices = index.search(np.array([target_vec]), len(word_vecs))

    # 類似度スコアを計算し、0%〜100%に正規化
    similarities = []
    for i in range(len(indices[0])):
        cosine_sim = np.dot(word_vecs[indices[0][i]], target_vec) / (np.linalg.norm(word_vecs[indices[0][i]]) * np.linalg.norm(target_vec))
        similarity_percent = (cosine_sim + 1) / 2 * 100  # -1〜1の範囲を0%〜100%に変換
        similarity_percent = round(similarity_percent, 1)  # 四捨五入して小数点以下2桁に丸める
        similarities.append((result[indices[0][i]][0], result[indices[0][i]][1], similarity_percent))
        #similarities.append((result[indices[0][i]], similarity_percent))

        
    similarities = remove_duplicates(similarities)
    
    # 類似度スコアが高い順にソート
    result = sorted(similarities, key=lambda x: x[2], reverse=True)

    return result

app = Flask(__name__)

# セッションの設定
app.config['SECRET_KEY'] = 'sentaku'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)


db_config = {
    'host':'localhost',  # MySQLが動作しているホスト名
    'user':'sentaku',  # MySQLのユーザー名
    'password':'sentaku',  # MySQLのパスワード
    'database':'rapdic'  # 接続するデータベース名
    }

@app.route('/')
def index():
    history = session.get('history', [])[::-1][:10]
    favorites = session.get('favorites',[])
    return render_template('index.html', history=history, favorites=favorites)


@app.route('/search', methods=['POST'])
def search_post():
    search_word = request.form['search_word']
    return redirect(url_for('search_get', search_word=search_word))#url_for(データを送りたい関数名)

@app.route('/search/<search_word>', methods=['GET'])
def search_get(search_word):

    if not search_word:
        return redirect(url_for('index'))
    result = []#検索結果格納

    # 検索履歴をセッションに保存
    if 'history' not in session:
        session['history'] = []
    session['history'].append(search_word)
    if len(session['history']) > 10:  # 履歴が10件を超えたら、古い履歴を削除
        session['history'] = session['history'][-10:]
    # 検索履歴を新しい順に並べ替え
    history = session.get('history', [])[::-1][:10]

    favorites = session.get('favorites',[])
        
    #SQLゾーン
    connection = mysql.connector.connect(**db_config)#データベースに接続
    cursor = connection.cursor()#SQLを実行してくれる準備
    query = "SELECT word, vowels, hurigana FROM rapdic_main order by word desc" #母音が一致する単語を選択するクエリ
    cursor.execute(query)#SQLクエリを実行している
    results = cursor.fetchall()#実行結果をresultsに格納(wordすべて)
    cursor.close()#リソースの解放
    connection.close()

    words = [row[0] for row in results]
    vowels = [row[1] for row in results]
    hurigana = [row[2] for row in results]#検索結果のフリガナ取り出したい

    # 検索結果を取得
    result = search_result(search_word, words, vowels,hurigana)
    search_vowels = ExtractVowels.extract_vowels(search_word)

    return render_template('result.html', search_word=search_word, result=result, search_vowels = search_vowels, history=history,favorites=favorites)#検索結果をTempleteに渡す

# お気に入りに追加する関数
@app.route('/add_favorite/<search_word>/<result_word>', methods=['GET'])
def add_favorite(search_word,result_word):
    pair = (search_word, result_word)
    # セッションにお気に入りの単語を追加
    if 'favorites' not in session:
        session['favorites'] = []
    session['favorites'].append(pair)
    session['favorites'] = list(set(session['favorites']))  # 重複削除
    print(session['favorites'] )
    flash(f"'{search_word}' と '{result_word}' をお気に入りに追加しました。")

    # リダイレクト元のURLに戻る
    referrer_url = request.referrer
    if referrer_url:
        return redirect(referrer_url)
    else:
        return redirect(url_for('index'))

# お気に入りから削除する関数
@app.route('/remove_favorite/<search_word>/<result_word>', methods=['GET'])
def remove_favorite(search_word,result_word):
    # セッションからお気に入りの単語を削除
    if 'favorites' in session:
        session['favorites'] = [pair for pair in session['favorites'] if pair != (search_word, result_word)]

    # リダイレクト元のURLに戻る
    referrer_url = request.referrer
    if referrer_url:
        return redirect(referrer_url)
    else:
        return redirect(url_for('index'))

@app.route('/clear_favorites')
def clear_favorites():
    session.pop('favorites', None)
    # リダイレクト元のURLに戻る
    referrer_url = request.referrer
    if referrer_url:
        return redirect(referrer_url)
    else:
        return redirect(url_for('index'))

@app.route('/clear')
def clear_history():
    session.pop('history', None)
    # リダイレクト元のURLに戻る
    referrer_url = request.referrer
    if referrer_url:
        return redirect(referrer_url)
    else:
        return redirect(url_for('index'))

@app.route("/music/<path:filename>")#音楽再生
def play(filename):
    return send_from_directory("music", filename)

if __name__ == '__main__':
    app.run(debug=True)
