import pykakasi
import re
import alkana

def to_hiragana(word):
  toHiragana = pykakasi.kakasi()
  toHiragana.setMode('K','H')
  conv = toHiragana.getConverter()
  word = conv.do(word)
  return word


def extract_vowels(word):
  try:
    #母音を定義
    vowels = "aeiouAEIOU"

    #ここらへん漢字変換(きったないからあとでなおした
    kakasi_kanzi = pykakasi.kakasi()
    kakasi_kanzi.setMode('J','H')
    conv_kanzi = kakasi_kanzi.getConverter()
    word = conv_kanzi.do(word)#ここで漢字からひらがなになる
    kakasi_roma = pykakasi.kakasi()
    kakasi_hiragana = pykakasi.kakasi()

    kakasi_hiragana.setMode('K','H')
    kakasi_roma.setMode('H','a')
    conv_hiragana = kakasi_hiragana.getConverter()
    conv_roma = kakasi_roma.getConverter()
    word = conv_hiragana.do(word)#ここでカタカナからひらがなになる
    # word = conv.do(word)
    # conv = kakasi_katakana.getConverter()
    # word = conv.do(word)

    #print(word)

    #英語か、日本語かの場合分け
    if re.search(r'[ぁ-ゖ]+|[ァ-ヶ]+', word):
      #単語をローマ字変換
      word = conv_roma.do(word)
    elif re.search(r'[a-z]+|[A-Z]+|[Ａ-Ｚａ-ｚ]+',word):
      word = alkana.get_kana(word)#カタカナ語に変換
      word = kakasi_roma.convert(word)#カタカナ語に直したうえで、ローマ字変換
      for converted_word in word:
        word = f"{converted_word['hepburn']}"
    #単語から母音を抽出してリスト
    extracted_vowels = [char for char in word if char in vowels]
    return ''.join(extracted_vowels)
  except TypeError:
    extracted_vowels = ["この単語は無効です"]
    #print('この単語は無効です')
    return "この単語は無効です"
