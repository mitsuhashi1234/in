import Main
import ExtractVowels
from sklearn.metrics.pairwise import cosine_similarity


def search_result(search_word, all_words):
    target_vowels = ExtractVowels.extract_vowels(search_word) #検索ワードの母音を抜き出し
    
    for (word,) in all_words:#MySQLに入っている単語から母音を抜き出し、一致しているものをresultに格納
           if ExtractVowels.extract_vowels(word) == target_vowels:
               if word != search_word:#同じ単語が出てこないようにする処理
                #print(ExtractVowels.extract_vowels(word))
                  result.append(word)
               else:
                  result.append('なし')

    target_vec = Main.model.get_word_vector(search_word)#入力ワードのベクトル化
    word_vecs = [Main.model.get_word_vector(word) for word in result]#母音が一致しているワードのベクトル化
    
    similarities = cosine_similarity([target_vec], word_vecs)[0]
    pairs = list(zip(result, similarities))
    result = sorted(pairs, key=lambda x: x[1], reverse=True)

    return result
        
        